chrome.action.onClicked.addListener(async () => {
  chrome.windows.getCurrent(async (window) => {
    await chrome.sidePanel.open({
      windowId: window.id
    });
  });
});//enable sidepanel logic
const notificationId = 'systemhellonotification';
function getTargetLink(callback) {
  chrome.storage.sync.get(['default'], function(result) {
    const targetLink = result.default || "https://homework.saltcorn.com/page/ready"; //replace with ""
    console.log("Target URL:", targetLink);
    callback(targetLink);
  }); //needed for createnotificatoin
}
function createNotification(targetLink) {
  chrome.notifications.create(notificationId, {
    type:'basic',
    iconUrl:'assets/ext-icon.png', //please change this
    title:'Important Reminder',
    message:'Time to update your latest homework and assessment! Close this to snooze indefinitely.', //A bit long tbh
    buttons:[{title: 'Go to Link'},
    {title:'Snooze 5 minutes'},
    {title:'Snooze Indefinitely'}],
    priority:2
  });}
function createNotification2(targetLink) { //missed notifcation dummy notifcation, I might piss someone off if I didn't include this.
  chrome.notifications.create(notificationId, {
    type:'basic',
    iconUrl:'assets/ext-icon.png',
    title:'Not important Reminder, you missed a notification when you were away',
    message:'Snoozed',
    buttons:[{title: 'Go to Link'},
    {title:'Snooze 5 minutes'},
    {title:'Snooze Indefinitely'}],
    priority:2
  });}
function createNotificationstartup() {
  chrome.notifications.create(notificationId, {
    type:'basic',
    iconUrl:'assets/ext-icon.png',
    title:'Thank you for using Saltcorn Reminder! ',
    message:'Have a great day! ❤️',
    buttons:[{title: 'Go to Link'},
    {title:'Snooze 5 minutes'},
    {title:'Snooze Indefinitely'}],
    priority:2
  });}
function createNotificationinstall() {
  chrome.notifications.create(notificationId, {
    type:'basic',
    iconUrl:'assets/ext-icon.png',
    title:'Welcome! ',
    message:'To get started, click on our icon!',
    buttons:[{title:'Go to Link'},
    {title: 'Snooze 5 minutes'},
    {title: 'Snooze Indefinitely'}],
    priority: 2
  });}
function clearNotification() {
  chrome.notifications.clear(notificationId);
}
function openTargetLink(targetLink) {
  chrome.tabs.create({url: targetLink});
}
chrome.notifications.onButtonClicked.addListener((clickedNotificationId,buttonIndex) => {
getTargetLink(targetLink=>{
  switch (buttonIndex){
    case 0:
      openTargetLink(targetLink);
      clearNotification();
      break;
    case 1:
      clearNotification();
      setTimeout(()=>{
        minutecycle();
      }, 300000); //5 minutes
      break;
  }});}
);
function scheduleAlarms() {
  chrome.storage.sync.get(['reminderTimes','default','lastCheckTime'],(result)=>{
    if (chrome.runtime.lastError) {
      console.error("Error retrieving data:", chrome.runtime.lastError);
      return;}
    const targetTimes = result.reminderTimes || [];//lots of AI slop from here
    targetTimes.forEach(targetTime => {
      const [targetHour, targetMinute] = targetTime.split(":").map(Number);
      const alarmName = `reminder-${targetHour}-${targetMinute}`;
      chrome.alarms.clear(alarmName, (wasCleared) => {
        if (wasCleared) {console.log(`Cleared existing alarm: ${alarmName}`);}

        // Calculate when the alarm should trigger (in minutes from now)
        const now = new Date();
        const targetDate = new Date(now.getFullYear(), now.getMonth(), now.getDate(), targetHour, targetMinute, 0, 0);

        // If the target time is in the past, set it for the next day
        if (targetDate < now) {
          targetDate.setDate(targetDate.getDate() + 1);
        }

        const delayInMinutes = (targetDate.getTime() - now.getTime()) / (1000 * 60);

        // Create the alarm
        chrome.alarms.create(alarmName, {
          delayInMinutes: delayInMinutes
        });

        console.log(`Alarm set for ${targetTime}, will trigger in ${delayInMinutes} minutes`);
      });
    });
  });
}

// Listen for alarm events
chrome.alarms.onAlarm.addListener((alarm) => {
  console.log("Alarm triggered:", alarm.name);
  getTargetLink(targetLink => {
    createNotification(targetLink);
  });
});

// Schedule alarms when the extension is installed or updated
chrome.runtime.onInstalled.addListener(() => {
  console.log("Extension installed/updated. Scheduling alarms.");
  scheduleAlarms();
  createNotificationinstall(); //keep
});

// Reschedule alarms when Chrome starts
chrome.runtime.onStartup.addListener(() => {
  console.log("Chrome started. Scheduling alarms.");
  scheduleAlarms();
});

function minutecycle() { //was used for setinterval, now useless
  console.log("The cycle begins");
}

createNotificationstartup();
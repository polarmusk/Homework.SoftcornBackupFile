document.addEventListener('DOMContentLoaded', function() {
  // Helper function to check if an element exists
  function elementExists(elementId) {
    return document.getElementById(elementId) !== null;
  }

  // Function to display reminder times
  function displayReminderTimes() {
    chrome.storage.sync.get(['reminderTimes'], function(result) {
      if (chrome.runtime.lastError) {
        console.error("Error retrieving reminderTimes:", chrome.runtime.lastError);
        const timesList = document.getElementById('timesList');
        timesList.innerHTML = '<li class="error">Error loading reminder times. Please try again.</li>';
        return;
      }

      let reminderTimes = result.reminderTimes || [];
      const timesList = document.getElementById('timesList');
      timesList.innerHTML = '';

      reminderTimes.forEach(time => {
        const listItem = document.createElement('li');
        listItem.textContent = time;
        timesList.appendChild(listItem);
      });
    });
  }

  // Function to validate time format
  function isValidTimeFormat(time) {
    return /^([01]\d|2[0-3]):([0-5]\d)$/.test(time); //Like I genuely don't know what is this supposed to be but like ask stackflow or smt
  }

  // Function to test notifications
  function testNotifications() {
    chrome.notifications.create("testNotif", {
      type: 'basic',
      iconUrl: 'assets/ext-icon.png',
      title: 'Thank you for using Saltcorn Reminder!',
      message: 'I hope you have a good day!',
      buttons: [{
          title: 'Go to Link'
        },
        {
          title: 'Snooze 5 minutes'
        },
        {
          title: 'Snooze Indefinitely'
        }
      ],
      priority: 2
    });
  }

  function resetTutorial() {
    localStorage.removeItem('setupSaltcorn');
    localStorage.removeItem('setupSubmitButton');
    currentImageIndex = 0;
    updateImage();
  }

  // Function to set up for Saltcorn
  function setupForSaltcorn() {
    currentImageIndex = 1;
    updateImage();
    localStorage.setItem('setupSaltcorn', 'true');
  }

  // Function to set up for Submit
  function setupforSubmit() {
    currentImageIndex = 10;
    updateImage();
    localStorage.setItem('setupSubmitButton', 'true');
  }

  // Function to check Saltcorn setup
  function checkSaltcorn() {
    if (localStorage.getItem('setupSaltcorn') === 'true') {
      currentImageIndex = 1;
      updateImage();
    }
    if (localStorage.getItem('setupSubmitButton') === 'true') {
      currentImageIndex = 10;
      updateImage();
    }
  }

  // Image and text data
  const images = [
    "images/github4.png",
    "images/github2.png",
    "images/githhub8.png",
    "images/github10.png",
    "images/github9.png",
    "images/github11.png",
    "images/github11.png",
    "images/github13.png",
    "images/github12.png",
    "images/dummyBlack.png",
    "images/github13.png"
  ];

  const pageSpecificText = {
    0: "Enter reminder time (HKT, 24-hour format) or 00:00 to skip: We recommend that you set it five minute before class ends so you don't forget anything.",
    1: "Download the code in zip file. Extract it and place it somewhere accessible.",
    2: "Got to saltcorn.com. This is where you make YOUR own domain!",
    3: "Press try it now, make a domain and press create!",
    4: "You got this! Click on the new website! Use the Back-up File you downloaded, and put it to good use!",
    5: "Don't worry, you'll get to use your very own website very soon!",
    6: "Gmail: homework@gmail.com Password: saltcorn4life When you are on this page, DO NOT CREATE AN ACCOUNT! You can make one later, but you need to sign in with administrator first.",
    7: "Enter your website URL below. This will be used as the default URL.",
    8: "That's it! I hope you will have the best time using Softcorn Reminders!",
    9: `You need to set a default URL for the notifications! It will determine where the notification will take you!
        It is recommended to choose our default Softcorn Calendar. It is tailored for setting tasks and homework, so it has better focus and less crankier menus.
        If you want, you can use a custom URL.`,
    10: "You made it to the settings..."
  };

  // Initialize variables
  let currentImageIndex = 0;
  let lastVisitedPage = 0;
  let reminderTime = null;

  // Get DOM elements
  const isButton = document.getElementById('isButton');
  const currentImage = document.getElementById("currentImage");
  const prevButton = document.getElementById("prevButton");
  const nextButton = document.getElementById("nextButton");
  const sidebarLinks = document.querySelectorAll(".sidebar ul li");
  const pageTextDiv = document.getElementById("pageText");
  const currentPageDiv = document.getElementById("currentPage");
  const urlInputContainer = document.getElementById("urlInputContainer");
  const urlInput = document.getElementById("urlInput");
  const saveUrlButton = document.getElementById("saveUrlButton");
  const timeInputContainer = document.getElementById("timeInputContainer");
  const timeInput = document.getElementById("timeInput");
  const timeError = document.getElementById("timeError");
  const timeDisplay = document.getElementById("timeDisplay");
  const resetTimeButton = document.getElementById("resetTimeButton");
  const errorMessageDiv = document.getElementById("errorMessage"); // Get the error message div
  const urlDisplayDiv = document.getElementById("urlDisplay");

  // Update the image and UI based on currentImageIndex
  function updateImage() {
    currentImage.src = images[currentImageIndex];
    updateSidebar();
    updatePageText();
    updateCurrentPageDisplay();

    const navigationDiv = document.getElementById("navigation");
    navigationDiv.innerHTML = "";

    urlInputContainer.style.display = "none";
    urlDisplayDiv.style.display = (currentImageIndex === 7 || currentImageIndex === 8) ? "block" : "none";
    urlInputContainer.style.display = currentImageIndex === 7 ? "block" : "none";

    // Button Logic for page 10
    if (currentImageIndex === 10) {
      let buttonHTML = `<button id="testNotif">Test Notifications</button>
                          <button id="resetTutorialButton">Reset Tutorial</button>`;
      navigationDiv.insertAdjacentHTML('beforeend', buttonHTML);

      const testNotif = document.getElementById('testNotif');
      const homepage = document.getElementById('resetTutorialButton');

      if (testNotif) {
        testNotif.addEventListener('click', testNotifications);
      }
      if (homepage) {
        homepage.addEventListener('click', resetTutorial);
      }
    }

    // Page-specific UI updates
    if (currentImageIndex === 0) {
      timeInputContainer.style.display = "block";
      imageContainer.style.display = "none";
      if (elementExists("prevButton")) {
        prevButton.style.display = "none";
      }
      if (elementExists("nextButton")) {
        nextButton.style.display = "none";
      }
      timeDisplay.style.display = "none";
      resetTimeButton.style.display = "block";
    } else if (currentImageIndex === 9) {
      timeInputContainer.style.display = "none";
      imageContainer.style.display = "block";
      if (elementExists("prevButton")) {
        prevButton.style.display = "none";
      }
      if (elementExists("nextButton")) {
        nextButton.style.display = "none";
      }
      resetTimeButton.style.display = "none";
      urlDisplayDiv.style.display = "none";

      navigationDiv.innerHTML = `
        <button id="useSaltcornButton">Use Saltcorn Calendar</button>
        <button id="setCustomUrlButton">Set Custom URL</button>
      `;

      const useSaltcornButton = document.getElementById("useSaltcornButton");
      const setCustomUrlButton = document.getElementById("setCustomUrlButton");

      if (useSaltcornButton) {
        useSaltcornButton.addEventListener("click", setupForSaltcorn);
      }

      if (setCustomUrlButton) {
        setCustomUrlButton.addEventListener("click", () => {
          urlInputContainer.style.display = "block";
          navigationDiv.innerHTML = "";

          const saveUrlButton = document.createElement("button");
          saveUrlButton.id = "saveUrlButton";
          saveUrlButton.textContent = "Save URL";
          navigationDiv.appendChild(saveUrlButton);

          saveUrlButton.addEventListener("click", () => {
            let url = urlInput.value;
            url = url.trim();
            if (!url.startsWith('http://') && !url.startsWith('https://') && url !== "") {
              // Add https:// if it's missing
              url = 'https://' + url; //doesn't fucking work
            }
            chrome.storage.sync.set({
              default: url
            }, function() {
              console.log("URL saved: " + url);
              alert("URL saved: " + url + "\nThank you for using Saltcorn Reminder");
              console.log("Hi?")
              currentImageIndex = 1;
              updateImage();
            });
          });
        });
      }
    } else {
      timeInputContainer.style.display = "none";
      imageContainer.style.display = "block";
      if (elementExists("prevButton")) {
        prevButton.style.display = currentImageIndex === 1 ? "none" : "inline-block";
      }
      if (elementExists("nextButton")) {
        nextButton.style.display = "inline-block";
      }
      resetTimeButton.style.display = "none";
      urlDisplayDiv.style.display = "none";
      if (reminderTime) {
        timeDisplay.textContent = `Reminder set for: ${reminderTime}`;
        timeDisplay.style.display = "block";
        resetTimeButton.style.display = "inline-block";
      } else {
        timeDisplay.style.display = "none";
        resetTimeButton.style.display = "none";
      }
    }

    if (currentImageIndex === 8) {
      const prevButton = document.createElement("button");
      prevButton.id = "prevButton";
      prevButton.textContent = "Previous";
      navigationDiv.appendChild(prevButton);

      const submitButton = document.createElement("button");
      submitButton.id = "submitButton";
      submitButton.textContent = "Submit URL";
      navigationDiv.appendChild(submitButton);

      chrome.storage.sync.get(['default'], function(result) {
        const savedUrl = result.default || "No URL saved";
        urlDisplayDiv.textContent = "URL: " + savedUrl;
      });

      prevButton.addEventListener("click", () => {
        currentImageIndex--;
        updateImage();
      });

      submitButton.addEventListener("click", () => {
        chrome.storage.sync.get(['default'], function(result) {
          const savedUrl = result.default || "No URL saved";
          alert("Submitted URL: " + savedUrl);
        });
        setupforSubmit();
      });
    } else if (currentImageIndex > 0 && currentImageIndex < 9) {
      const prevButton = document.createElement("button");
      prevButton.id = "prevButton";
      prevButton.textContent = "Previous";
      navigationDiv.appendChild(prevButton);

      const nextButton = document.createElement("button");
      nextButton.id = "nextButton";
      nextButton.textContent = "Next";
      navigationDiv.appendChild(nextButton);

      prevButton.addEventListener("click", () => {
        currentImageIndex--;
        updateImage();
      });

      if (currentImageIndex === 1) {
        prevButton.style.display = "none";
      }

      nextButton.addEventListener("click", () => {
        if (currentImageIndex === 7) {
          chrome.storage.sync.get(['default'], function(result) {
            let savedUrlValue = result.default || "";

            // Trim whitespace
            savedUrlValue = savedUrlValue.trim();

            // Check if the URL already has a protocol
            if (!savedUrlValue.startsWith('http://') && !savedUrlValue.startsWith('https://') && savedUrlValue !== "") {
              // Add https:// if it's missing
              savedUrlValue = 'https://' + savedUrlValue;
            }

            if (!savedUrlValue.includes("saltcorn.com")) {
              errorMessageDiv.style.display = "block";
              return;
            } else {
              errorMessageDiv.style.display = "none";
            }
            currentImageIndex++;
            updateImage();
          });
        } else {
          currentImageIndex++;
          updateImage();
        }
      });
      lastVisitedPage = currentImageIndex;
    }
  }

  // Function to update the sidebar
  function updateSidebar() {
    sidebarLinks.forEach((link, index) => {
      if (index === currentImageIndex - 1) {
        link.classList.add("active");
      } else {
        link.classList.remove("active");
      }
    });
  }

  // Function to update the page text
  function updatePageText() {
    const text = pageSpecificText[currentImageIndex] || "";
    pageTextDiv.textContent = text;
  }

  // Function to update the current page display
  function updateCurrentPageDisplay() {
    currentPageDiv.textContent = `Page: ${currentImageIndex}`;
  }

  // Function to attach sidebar listeners
  function attachSidebarListeners() {
    sidebarLinks.forEach((link, index) => {
      link.addEventListener("click", () => {
        currentImageIndex = index + 1;
        updateImage();
      });
    });
  }
  isButton.addEventListener('click', () => {
    const isT = ["09:15", "10:25", "11:50", "13:00", "14:55"];
    chrome.storage.sync.set({
      reminderTimes: isT //Stands for Island School time
    }, function() {
      console.log("isT");
      displayReminderTimes();
      currentImageIndex = 9;
      updateImage();
    });
  });

  // Event listener for saving the URL
  // Event listener for saving the URL
  if (saveUrlButton) {
    saveUrlButton.addEventListener("click", () => {
      let url = urlInput.value;
      url = url.trim();
      if (!url.startsWith('http://') && !url.startsWith('https://') && url !== "") {
        url = 'https://' + url;
      }
      chrome.storage.sync.set({
        default: url
      }, function() {
        console.log("URL saved: " + url);
        alert("URL saved: " + url + "\nThank you for using Saltcorn Reminder");
      });
    });
  }

  // Event listener for time input
  timeInput.addEventListener("keydown", (event) => {
    if (event.key === "Enter") {
      let time = timeInput.value;

      if (time === "00:00") {
        chrome.storage.sync.get(['reminderTimes'], function(result) {
          let reminderTimes = result.reminderTimes || [];
          displayReminderTimes()
          currentImageIndex = 9;
          updateImage();
        });
      } else if (isValidTimeFormat(time)) {
        if (time.length === 4) {
          time = "0" + time;
        }

        chrome.storage.sync.get(['reminderTimes'], function(result) {
          let reminderTimes = result.reminderTimes || [];
          reminderTimes.push(time);
          chrome.storage.sync.set({
            reminderTimes: reminderTimes
          }, function() {
            console.log("Reminder time added: " + time);
            timeInput.value = "";
            displayReminderTimes()
          });
        });
      } else {
        timeError.style.display = "block";
      }
    }
  });

  // Event listener for resetting reminder times
  resetTimeButton.addEventListener("click", () => {
    chrome.storage.sync.remove('reminderTimes', function() {
      console.log('Reminder times cleared');
      const timesList = document.getElementById('timesList');
      timesList.innerHTML = '';
      currentImageIndex = 0;
      updateImage();
    });
  });

  // Initialize the app
  checkSaltcorn();
  attachSidebarListeners();
  updateImage();
  displayReminderTimes();
});